# L&K Group 웹 서비스 구축 계획

2026년 9월 25일 · 계획 버전 1.0 · 기준 지역 Australia/Sydney · 문서 언어 한국어

L&K Group의 서비스 홈페이지, 온라인 쇼핑몰, ERP·CRM 운영관리 시스템을 구축하기 위한 개발 참조 문서다. 현재 확인한 자산은 ChatGPT 프로젝트의 대화 3개와 화면 시안 3개다. 실행 가능한 웹사이트나 데이터베이스 구현이 확인된 상태는 아니다.

권장 방향은 **하나의 고객·운영 데이터 기반 위에 서비스 예약과 상품 구매 흐름을 구분하고, 서비스 매출부터 단계적으로 운영을 검증하는 것**이다. 핸디맨·페인팅·캐비넷 페인팅과 터치업 키트·김치는 동일 관리자에서 관리하되, 식품의 배송·위생·재고 정책은 별도로 적용한다. 사용자가 ESN의 의미를 ERP·CRM 중심으로 확정했다.

## 읽는 순서

| 문서 | 개발에서 참조할 내용 |
| --- | --- |
| [00 기존 프로젝트 분석](docs/plans/00-project-baseline.md) | 확인된 시안, 기존 결정, 새 요청과의 차이 |
| [01 사업 목표와 범위](docs/plans/01-product-scope.md) | 단계별 범위, 이용자, 요구사항 ID |
| [02 화면과 고객 여정](docs/plans/02-information-architecture.md) | 사이트맵, 페이지 구성, 모바일 흐름 |
| [03 기술 구조와 배포](docs/plans/03-architecture-and-deployment.md) | Next.js, Supabase, Vercel, Docker 역할 |
| [04 데이터와 권한](docs/plans/04-data-model-and-access.md) | 테이블, 상태, 원장, 데이터 접근 |
| [05 자동견적과 예약](docs/plans/05-quote-ai-booking.md) | 정찰제, 사진 분석, 승인, 일정, 변경견적 |
| [06 쇼핑몰과 재고](docs/plans/06-commerce-and-inventory.md) | 키트, 김치, 결제, 배송, 반품 |
| [07 자동화와 운영](docs/plans/07-automation-and-operations.md) | 이메일, 인보이스, 장애 복구, 관리자 SOP |
| [08 보안과 호주 운영 조건](docs/plans/08-security-and-compliance.md) | 고객 사진, 개인정보, 계약, 식품 판매 조건 |
| [09 테스트와 출시 검증](docs/plans/09-test-and-qa.md) | 테스트 시나리오, AI 평가, UAT, 출시 기준 |
| [10 일정과 비용](docs/plans/10-roadmap-budget-risks.md) | 인력, 의존성, 공수, 운영비, 위험 |
| [11 서비스 마케팅](docs/plans/11-marketing-and-growth.md) | 고객군, SEO, 광고, 콘텐츠, 90일 실행 |
| [12 개발 백로그](docs/plans/12-implementation-backlog.md) | 구현 순서, 완료 기준, 담당 역할 |
| [13 모델과 개발 운영](docs/plans/13-ai-development-workflow.md) | Astra xhigh / Sol high 작업 기준 |
| [14 결정과 출처](docs/plans/14-decisions-and-sources.md) | 확정·제안·미정 구분과 공식 근거 |

클라이언트 전달본은 [Word 구현계획서](deliverables/LK_Group_Client_Implementation_Plan_KO.docx)이며, 편집 가능한 원문은 [클라이언트 제안서 Markdown](docs/client-proposal.md)이다. 기술 기준은 위 개발 문서가 원본이며, 클라이언트 문서를 변경할 때 관련 개발 문서도 함께 갱신한다. 문서 자체의 확인 결과는 [검증 기록](docs/document-validation.md)에 정리했다.

## 계획의 사용 기준

- 일정·가격·전환율은 사업 자료가 없는 상태에서 세운 **계획 가정**이다. 승인된 계약금액, 견적 단가 또는 실적이 아니다.
- 고객용 영어 사이트를 우선하고 한국어 콘텐츠를 다음 단계에서 추가하는 안이다. 브랜드명과 법인·ABN·GST 등록 상태는 착수 단계에서 확인한다.
- 고객 서비스 지역은 기존 요청을 따라 Ermington 기준 15km 반경을 기본안으로 둔다. 중심 좌표, 경계값 포함 여부, 도로거리 전환 여부는 결정표에서 확정한다.
- 실제 서비스 판매가격은 비워 두고, 산식 설명용 가격은 모두 예시로 표시한다.
- 이번 산출물은 계획서와 프로젝트 작업 설정이다. 앱 배포, 결제 계정 개설, DB 생성, 광고 집행은 수행하지 않는다.

## 첫 착수 회의 산출물

대표가 승인할 항목은 판매 사업자와 서비스 자격, 초기 서비스 목록, 정찰제 포함 범위, 서비스 중심 주소, 키트 SKU, 김치 제조·배송 방법, 목표 예산, 출시 담당자다. 이 자료를 [결정표](docs/plans/14-decisions-and-sources.md)에 기록하면 개발 백로그의 준비 단계부터 시작할 수 있다.
